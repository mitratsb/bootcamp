#Mitratsb
h=float(input("Ertefa: "))
l=float(input("Ghaede: "))

s = (h*l)/2
print(f'Masahate mosalas : {s}')
