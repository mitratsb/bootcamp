#Mitratsb
a=input('a: ')
b=input('b: ')

print(f'id(a) is {id(a)}\nid(b) is {id(b)}')

