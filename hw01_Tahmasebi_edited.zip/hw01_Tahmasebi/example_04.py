#Mitratsb
a=input("a : ")
b=input("b : ")

a,b = b,a

print(f'a={a} , b={b}')
