#Mitratsb
list1=[1,2,3,4,5,6,7,8,9]

for num in list1:
    print(f'number:{num} -> tavan2:{num**2} , tavan3:{num**3}, tavan4:{num**4}')

    
    
    
