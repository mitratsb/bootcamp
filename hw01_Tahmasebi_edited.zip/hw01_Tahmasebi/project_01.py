#Mitratsb
a=list(input("Enter a number with 5 digits : "))

if len(a)==5:
    print(a[0],'',a[1],'',a[2],'',a[3],'',a[4])
else:
    print("this number is not valid, run the program again.")







    




