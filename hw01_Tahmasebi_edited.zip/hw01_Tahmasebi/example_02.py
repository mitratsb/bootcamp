#Mitratsb
from math import sqrt

a=float(input("a : "))
b=float(input("b : "))

f=sqrt(a**b)

print(f'function result : {f}')

