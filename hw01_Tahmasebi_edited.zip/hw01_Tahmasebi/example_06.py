#Mitratsb
x=float(input("initial speed : "))
k=float(input("final speed : "))
n=float(input("minutes : "))

a = ((k-x)*60)/n 
print(f'acceleration : {a}')

# این سوال هم فرمول اشتباهی داشت و به جای 60 عدد 20 رو داده بود که تصحیح شد
