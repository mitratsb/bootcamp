#Mitratsb
x=input("number : ")

a1=x[0]
b1=x[1]

a2=int(a1)
b2=int(b1)

res1 = a2**b2
res2 = b2**a2

print(f'first result : {res1} \nsecond result : {res2}')
